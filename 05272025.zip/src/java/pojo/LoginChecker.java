/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

import database.DataBaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Abhinav Verma
 */
public class LoginChecker {
    
    
    
    public static boolean isValid(String email, String password){
    
        
        try{
        String tablepassword;
        Connection connection = DataBaseConnection.getConnection();
        String query="SELECT (password) FROM USERS WHERE email=?";
        PreparedStatement pst=connection.prepareStatement(query);
        pst.setString(1, email);
        
        ResultSet rs=pst.executeQuery();
        
        if(rs.next()){
        
        
            tablepassword = rs.getString("password");
        }
        else{ 
            return false;
        }
        
        if(tablepassword.equals(password)){ return true;}
        
                }
        catch(Exception e){}
        
    return false;
    }
    
}
