/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

import database.DataBaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Abhinav Verma
 */
public class SignUp_POJO {
    
    
    
    
    public static boolean addNewUser(String email, String password){
    
    try{
        
       String query ="INSERT INTO USERS  (email, password) VALUES (?,?)"; 
       Connection con =DataBaseConnection.getConnection();
       
       PreparedStatement pst= con.prepareStatement(query);
       pst.setString(1, email);
       pst.setString(2, password);
      
        int x= pst.executeUpdate();
        if(x!=0){
        return true;
        }
       
        
//       
//        System.out.print(email);
//        System.out.print(password);
        
        }
        catch(Exception e){
        System.out.println(e);
        return false;
        }
    return false;
    }
    
}
