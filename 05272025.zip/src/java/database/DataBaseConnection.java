/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;

/**
 *
 * @author Abhinav Verma
 */
public class DataBaseConnection {
    
    static Connection con;
    static Statement st;
    private static  String url = "jdbc:mysql://localhost:3306/parkingslotsystem?useSSL=false";
      private static String username = "root";
      private static  String password = "root";
    
   static{
    try{
     Class.forName("com.mysql.jdbc.Driver");
      con= DriverManager.getConnection(url,username,password);
       st=con.createStatement();
    
    }
    catch(Exception e){
    System.out.print("Error While Conecting To dataBase ");
    }
   }
   
   
   public static Statement getStatement(){
   
   return st;
   }
   
   public static Connection getConnection(){
   return con;
   }
   
   
   }
    
    

